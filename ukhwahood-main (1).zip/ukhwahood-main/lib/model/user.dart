class User {
  int? id;
  String? name, email, gender, state, socialUrl, bio, education, image;
  int? pray, level, fardu;
  DateTime? birthDate;
  User({
    this.id,
    this.name,
    this.email,
    this.gender,
    this.birthDate,
    this.state,
    this.pray,
    this.level,
    this.fardu,
    this.socialUrl,
    this.bio,
    this.education,
    this.image,
  });
}
