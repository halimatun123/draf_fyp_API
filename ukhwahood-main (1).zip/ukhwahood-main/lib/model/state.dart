class State {
  int? id;
  String? name;

  State({this.id, this.name});
}
