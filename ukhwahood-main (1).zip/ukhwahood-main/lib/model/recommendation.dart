class Recommendation {
  String profileUrl, name;
  Recommendation(this.profileUrl, this.name);
}
