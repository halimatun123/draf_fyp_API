import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';

class CustomIcon {
  static final SvgPicture discover = SvgPicture.asset("asset/svg/Discover.svg");
  static final Image channel = Image.asset("asset/img/Channel.png");
  static final SvgPicture message = SvgPicture.asset("asset/svg/Message.svg");
  static final SvgPicture profile = SvgPicture.asset("asset/svg/Profile.svg");
}
