class Error {
  final String message;

  const Error(this.message);

  @override
  String toString() {
    return 'Error: $message';
  }
}
