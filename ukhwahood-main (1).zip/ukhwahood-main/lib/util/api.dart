import 'dart:convert';
import 'package:http/http.dart' as http;

abstract class Api {
  // static const String baseUri = 'http://192.168.0.101/tun/api';
  static const String baseUri = 'http://192.168.108.218/fyp_ukhwahood/api';
  static Future<Map<String, dynamic>> get(
    String route, [
    Map<String, String>? headers,
  ]) async {
    final res = await http.get(
      Uri.parse('${Api.baseUri}$route'),
      headers: headers,
    );
    return jsonDecode(res.body);
  }

  static Multipart get multipart => Multipart();
}

class Multipart extends Api {
  static Future<Map<String, dynamic>> _method(
    String method,
    String route, [
    Map<String, String>? headers,
    Map<String, dynamic>? data,
  ]) async {
    final req =
        http.MultipartRequest(method, Uri.parse('${Api.baseUri}$route'));
    if (headers != null) req.headers.addAll(headers);
    if (data != null) {
      for (final entry in data.entries) {
        if (entry.value is http.MultipartFile) {
          req.files.add(entry.value);
        } else {
          req.fields[entry.key] = entry.value.toString();
        }
      }
    }
    final res = await req.send();
    return jsonDecode(await res.stream.bytesToString());
  }

  Future<Map<String, dynamic>> post(
    String route, [
    Map<String, dynamic>? data,
    Map<String, String>? headers,
  ]) {
    return _method('POST', route, headers, data);
  }

  Future<Map<String, dynamic>> put(
    String route, [
    Map<String, dynamic>? data,
    Map<String, String>? headers,
  ]) {
    return _method('PUT', route, headers, data);
  }
}
