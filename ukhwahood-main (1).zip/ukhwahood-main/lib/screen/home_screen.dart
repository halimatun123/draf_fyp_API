import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:ukhwahood/custom_icon.dart';
import 'package:ukhwahood/screen/channel_screen.dart';
import 'package:ukhwahood/screen/discover_screen.dart';
import 'package:ukhwahood/screen/login_screen.dart';
import 'package:ukhwahood/screen/messages_screen.dart';
import 'package:ukhwahood/screen/profile_screen.dart';
import 'package:ukhwahood/util/error.dart';

class Menu {
  static final discover = Menu("Discover", CustomIcon.discover);
  static final channel = Menu("Channel", CustomIcon.channel);
  static final message = Menu("Messages", CustomIcon.message);
  static final profile = Menu("profile", CustomIcon.profile);

  final String title;
  final Widget icon;
  const Menu(this.title, this.icon);
  static List<Menu> values() {
    return [discover, channel, message, profile];
  }
}

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<StatefulWidget> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _menu = 1;
  late String authToken;

  Widget _getPage() {
    switch (_menu) {
      case 0:
        return DiscoverScreen(authToken);
      case 1:
        return const ChannelScreen();
      case 2:
        return const MessagesScreen();
      case 3:
        return const ProfileScreen();
      default:
        return const Center(child: Text('Not implemented!'));
    }
  }

  Future<void> _init() async {
    final prefs = await SharedPreferences.getInstance();
    try {
      if (!prefs.containsKey('AUTH_TOKEN')) throw const Error('Not logged in!');
      authToken = prefs.getString('AUTH_TOKEN')!;
    } on Error catch (_) {
      if (mounted) {
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(
            builder: (context) => const LoginScreen(),
          ),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return FutureBuilder(
      future: _init(),
      builder: (context, snapshot) {
        return Scaffold(
          body: _getPage(),
          bottomNavigationBar: Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [
                  Theme.of(context).colorScheme.primary,
                  Theme.of(context).colorScheme.secondary,
                ],
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
              ),
            ),
            child: BottomNavigationBar(
              type: BottomNavigationBarType.fixed,
              backgroundColor: Colors.transparent,
              selectedItemColor: Colors.white,
              unselectedItemColor: Colors.white,
              showSelectedLabels: false,
              showUnselectedLabels: false,
              items: Menu.values()
                  .map(
                    (menu) => BottomNavigationBarItem(
                      label: menu.title,
                      icon: ClipOval(
                        child: Container(
                          padding: const EdgeInsets.all(10),
                          decoration: Menu.values()[_menu] == menu
                              ? const BoxDecoration(color: Colors.white)
                              : null,
                          child: ColorFiltered(
                            colorFilter: ColorFilter.mode(
                              Menu.values()[_menu] == menu
                                  ? Theme.of(context).colorScheme.secondary
                                  : Colors.white,
                              BlendMode.srcIn,
                            ),
                            child: menu.icon,
                          ),
                        ),
                      ),
                    ),
                  )
                  .toList(),
              currentIndex: _menu,
              onTap: (value) {
                setState(() {
                  _menu = value;
                });
              },
            ),
          ),
        );
      },
    );
  }
}
