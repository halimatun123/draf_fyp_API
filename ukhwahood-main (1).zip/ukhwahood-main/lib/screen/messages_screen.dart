import 'package:flutter/material.dart';
import 'package:ukhwahood/model/recommendation.dart';

class MessagesScreen extends StatefulWidget {
  const MessagesScreen({super.key});

  @override
  State<StatefulWidget> createState() => _MessagesScreenState();
}

class _MessagesScreenState extends State<MessagesScreen> {
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(20),
      child: Column(
        mainAxisSize: MainAxisSize.max,
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Text(
            'Recommendations',
            style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                  color: Colors.red,
                ),
          ),
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: Row(
              mainAxisSize: MainAxisSize.max,
              children: [
                Recommendation('https://i.imgur.com/1lOZzsQ.png', 'Khadijah'),
                Recommendation('https://i.imgur.com/ZpfQHLw.png', 'Khalid'),
                Recommendation('https://i.imgur.com/69RucaO.png', 'Sarah'),
                Recommendation('https://i.imgur.com/gleO45W.png', 'Syifa'),
                Recommendation('https://i.imgur.com/bHyk0WS.png', 'Adib'),
                Recommendation('https://i.imgur.com/gSNamfQ.png', 'Akmal'),
                Recommendation('https://i.imgur.com/2w205ST.png', 'Izzat'),
                Recommendation('https://i.imgur.com/WERwgjG.png', 'Amira'),
                Recommendation('https://i.imgur.com/bhF542G.png', 'Anissa'),
                Recommendation('https://i.imgur.com/XbtwJuZ.png', 'Puteri'),
              ]
                  .map(
                    (r) => Padding(
                      padding: const EdgeInsets.all(5),
                      child: Column(
                        children: [
                          ClipOval(
                            child: Image.network(
                              r.profileUrl,
                              width: 48,
                              height: 48,
                            ),
                          ),
                          Text(
                            r.name,
                            style:
                                Theme.of(context).textTheme.bodySmall?.copyWith(
                                      fontSize: 10,
                                    ),
                          ),
                        ],
                      ),
                    ),
                  )
                  .toList(),
            ),
          ),
          Expanded(
            child: Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(10),
                gradient: const LinearGradient(
                  colors: [Colors.yellow, Colors.red],
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                ),
              ),
              padding: const EdgeInsets.all(10),
              child: Column(
                mainAxisSize: MainAxisSize.max,
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Text(
                    'Messages',
                    style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                          color: Colors.red,
                        ),
                  ),
                  const SizedBox(height: 10),
                  Expanded(
                    child: ListView.separated(
                      itemCount: 20,
                      itemBuilder: (ctx, idx) => Row(
                        // crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          ClipOval(
                            child: Image.network(
                              'https://i.imgur.com/XbtwJuZ.png',
                              width: 48,
                              height: 48,
                            ),
                          ),
                          const SizedBox(width: 10),
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                'Sophie',
                                style: Theme.of(context)
                                    .textTheme
                                    .bodyMedium
                                    ?.copyWith(),
                              ),
                              Text(
                                'How are you?',
                                style: Theme.of(context)
                                    .textTheme
                                    .bodyMedium
                                    ?.copyWith(
                                      color: Colors.grey,
                                    ),
                              ),
                            ],
                          ),
                        ],
                      ),
                      separatorBuilder: (ctx, idx) => const SizedBox(
                        height: 5,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
