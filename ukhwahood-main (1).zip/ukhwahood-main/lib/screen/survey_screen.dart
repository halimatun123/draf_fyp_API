import 'package:flutter/material.dart';
import 'package:ukhwahood/model/state.dart' as state;
import 'package:ukhwahood/util/api.dart';
import 'package:ukhwahood/util/error.dart';

class SurveyScreen extends StatefulWidget {
  const SurveyScreen({super.key});

  @override
  State<StatefulWidget> createState() => _SurveyScreenState();
}

class _SurveyScreenState extends State<SurveyScreen> {
  final _controller = PageController();
  int _page = 0;
  String? _gender, _pray, _unLevel, _fardu;
  int? _state, _age;

  Future<List<state.State>> _getStates() async {
    List<state.State> states = [];
    final res = await Api.get('/states');
    if (!res['success']) throw Error(res['message']);
    for (final state in res['states']) {
      states.add(state.State(
        id: state['ID'],
        name: state['name'],
      ));
    }
    return states;
  }

  @override
  Widget build(BuildContext context) {
    return FutureBuilder(
      future: _getStates(),
      builder: (context, snapshot) {
        if (snapshot.hasError) {
          return Center(child: Text(snapshot.error!.toString()));
        }
        if (!snapshot.hasData) {
          return const Center(child: CircularProgressIndicator());
        }
        return Scaffold(
          body: Column(
            mainAxisSize: MainAxisSize.max,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Container(
                alignment: Alignment.center,
                padding: const EdgeInsets.all(20),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    SizedBox.square(
                      dimension: 60,
                      child: Image.asset("asset/img/logo-fyp.png"),
                    ),
                    const SizedBox(width: 10),
                    const Text(
                      'UKHWAHOOD',
                      style: TextStyle(
                        fontFamily: 'RacingSansOne',
                        // fontStyle: FontStyle. regular,
                        color: Colors.orange,
                        fontSize: 24,
                      ),
                    ),
                  ],
                ),
              ),
              Expanded(
                child: Padding(
                  padding: const EdgeInsets.all(20),
                  child: PageView(
                    controller: _controller,
                    children: [
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        children: [
                          Text(
                            "What's your gender?",
                            textAlign: TextAlign.center,
                            style: Theme.of(context)
                                .textTheme
                                .headlineMedium!
                                .copyWith(
                                  fontFamily: "PoetsenOne",
                                  color: Colors.black,
                                  fontWeight: FontWeight.bold,
                                ),
                          ),
                          const SizedBox(height: 20),
                          RadioListTile(
                            value: "Male",
                            groupValue: _gender,
                            activeColor: Colors.black,
                            onChanged: (value) {
                              setState(() {
                                _gender = "Male";
                                _controller.nextPage(
                                  duration: const Duration(milliseconds: 300),
                                  curve: Curves.linear,
                                );
                              });
                            },
                            title: Padding(
                              padding: const EdgeInsets.only(left: 20),
                              child: Text(
                                "Male",
                                style: Theme.of(context)
                                    .textTheme
                                    .headlineMedium!
                                    .copyWith(
                                      fontFamily: "PoetsenOne",
                                      color: Colors.black,
                                      fontWeight: FontWeight.bold,
                                    ),
                              ),
                            ),
                          ),
                          const SizedBox(height: 20),
                          RadioListTile(
                            value: "Female",
                            groupValue: _gender,
                            activeColor: Colors.black,
                            onChanged: (value) {
                              setState(() {
                                _gender = "Female";
                                _controller.nextPage(
                                  duration: const Duration(milliseconds: 300),
                                  curve: Curves.linear,
                                );
                              });
                            },
                            title: Padding(
                              padding: const EdgeInsets.only(left: 20),
                              child: Text(
                                "Female",
                                style: Theme.of(context)
                                    .textTheme
                                    .headlineMedium!
                                    .copyWith(
                                      fontFamily: "PoetsenOne",
                                      color: Colors.black,
                                      fontWeight: FontWeight.bold,
                                    ),
                              ),
                            ),
                          ),
                        ],
                      ),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        children: [
                          Text(
                            "What's your age?",
                            textAlign: TextAlign.center,
                            style: Theme.of(context)
                                .textTheme
                                .headlineMedium!
                                .copyWith(
                                  fontFamily: "PoetsenOne",
                                  color: Colors.black,
                                  fontWeight: FontWeight.bold,
                                ),
                          ),
                          const SizedBox(height: 20),
                          Container(
                            decoration: BoxDecoration(
                              border: Border.all(
                                color: Colors.grey,
                              ),
                              borderRadius: BorderRadius.circular(10),
                            ),
                            child: DropdownButton<int>(
                              isExpanded: true,
                              padding:
                                  const EdgeInsets.symmetric(horizontal: 20),
                              underline: const SizedBox(),
                              hint: const Text("Please select"),
                              items: List.generate(
                                46 - 13,
                                (index) => DropdownMenuItem(
                                  value: index + 13,
                                  child: Text(
                                    "${index + 13}",
                                  ),
                                ),
                              ),
                              value: _age,
                              onChanged: (value) {
                                setState(() {
                                  _age = value;
                                  _controller.nextPage(
                                    duration: const Duration(milliseconds: 300),
                                    curve: Curves.linear,
                                  );
                                });
                              },
                            ),
                          ),
                        ],
                      ),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        children: [
                          Text(
                            "Where do you live?",
                            textAlign: TextAlign.center,
                            style: Theme.of(context)
                                .textTheme
                                .headlineMedium!
                                .copyWith(
                                  fontFamily: "PoetsenOne",
                                  color: Colors.black,
                                  fontWeight: FontWeight.bold,
                                ),
                          ),
                          const SizedBox(height: 20),
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 20),
                            decoration: BoxDecoration(
                              border: Border.all(
                                color: Colors.grey,
                              ),
                              borderRadius: BorderRadius.circular(10),
                            ),
                            child: DropdownButton<int>(
                              underline: const SizedBox(),
                              isExpanded: true,
                              hint: const Text("Please select"),
                              items: snapshot.data!
                                  .map(
                                    (state) => DropdownMenuItem<int>(
                                      value: state.id,
                                      child: Text(state.name ?? 'N/A'),
                                    ),
                                  )
                                  .toList(),
                              value: _state,
                              onChanged: (int? value) {
                                setState(() {
                                  _state = value;
                                  _controller.nextPage(
                                    duration: const Duration(milliseconds: 300),
                                    curve: Curves.linear,
                                  );
                                });
                              },
                            ),
                          ),
                        ],
                      ),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        children: [
                          Text(
                            "Do you perform prayer 5 times a day?",
                            textAlign: TextAlign.center,
                            style: Theme.of(context)
                                .textTheme
                                .headlineMedium!
                                .copyWith(
                                  fontFamily: "PoetsenOne",
                                  color: Colors.black,
                                  fontWeight: FontWeight.bold,
                                  fontSize: 30,
                                ),
                          ),
                          const SizedBox(height: 20),
                          RadioListTile(
                            value: "Yes",
                            groupValue: _pray,
                            activeColor: Colors.black,
                            onChanged: (value) {
                              setState(() {
                                _pray = "Yes";
                                _controller.nextPage(
                                  duration: const Duration(milliseconds: 300),
                                  curve: Curves.linear,
                                );
                              });
                            },
                            title: Padding(
                              padding: const EdgeInsets.only(left: 20),
                              child: Text(
                                "Yes",
                                style: Theme.of(context)
                                    .textTheme
                                    .headlineMedium!
                                    .copyWith(
                                      fontFamily: "PoetsenOne",
                                      color: Colors.black,
                                      fontWeight: FontWeight.bold,
                                      fontSize: 24,
                                    ),
                              ),
                            ),
                          ),
                          const SizedBox(height: 20),
                          RadioListTile(
                            value: "No",
                            groupValue: _pray,
                            activeColor: Colors.black,
                            onChanged: (value) {
                              setState(() {
                                _pray = "No";
                                _controller.nextPage(
                                  duration: const Duration(milliseconds: 300),
                                  curve: Curves.linear,
                                );
                              });
                            },
                            title: Padding(
                              padding: const EdgeInsets.only(left: 20),
                              child: Text(
                                "No",
                                style: Theme.of(context)
                                    .textTheme
                                    .headlineMedium!
                                    .copyWith(
                                      fontFamily: "PoetsenOne",
                                      color: Colors.black,
                                      fontWeight: FontWeight.bold,
                                      fontSize: 24,
                                    ),
                              ),
                            ),
                          ),
                          const SizedBox(height: 20),
                          RadioListTile(
                            value: "Difficult to be consistent",
                            groupValue: _pray,
                            activeColor: Colors.black,
                            onChanged: (value) {
                              setState(() {
                                _pray = "Inconsistent";
                                _controller.nextPage(
                                  duration: const Duration(milliseconds: 300),
                                  curve: Curves.linear,
                                );
                              });
                            },
                            title: Padding(
                              padding: const EdgeInsets.only(left: 20),
                              child: Text(
                                "Difficult to be consistent",
                                style: Theme.of(context)
                                    .textTheme
                                    .headlineMedium!
                                    .copyWith(
                                      fontFamily: "PoetsenOne",
                                      color: Colors.black,
                                      fontWeight: FontWeight.bold,
                                      fontSize: 24,
                                    ),
                              ),
                            ),
                          ),
                        ],
                      ),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        children: [
                          Text(
                            "How do you rate your Islamic understanding level?",
                            textAlign: TextAlign.center,
                            style: Theme.of(context)
                                .textTheme
                                .headlineMedium!
                                .copyWith(
                                  fontFamily: "PoetsenOne",
                                  color: Colors.black,
                                  fontWeight: FontWeight.bold,
                                  fontSize: 30,
                                ),
                          ),
                          const SizedBox(height: 20),
                          RadioListTile(
                            value: "Low",
                            groupValue: _unLevel,
                            activeColor: Colors.black,
                            onChanged: (value) {
                              setState(() {
                                _unLevel = "Low";
                              });
                            },
                            title: Padding(
                              padding: const EdgeInsets.only(left: 20),
                              child: Text(
                                "Low",
                                style: Theme.of(context)
                                    .textTheme
                                    .headlineMedium!
                                    .copyWith(
                                      fontFamily: "PoetsenOne",
                                      color: Colors.black,
                                      fontWeight: FontWeight.bold,
                                      fontSize: 24,
                                    ),
                              ),
                            ),
                          ),
                          const SizedBox(height: 20),
                          RadioListTile(
                            value: "Moderate",
                            groupValue: _unLevel,
                            activeColor: Colors.black,
                            onChanged: (value) {
                              setState(() {
                                _unLevel = "Moderate";
                              });
                            },
                            title: Padding(
                              padding: const EdgeInsets.only(left: 20),
                              child: Text(
                                "Moderate",
                                style: Theme.of(context)
                                    .textTheme
                                    .headlineMedium!
                                    .copyWith(
                                      fontFamily: "PoetsenOne",
                                      color: Colors.black,
                                      fontWeight: FontWeight.bold,
                                      fontSize: 24,
                                    ),
                              ),
                            ),
                          ),
                          const SizedBox(height: 20),
                          RadioListTile(
                            value: "High",
                            groupValue: _unLevel,
                            activeColor: Colors.black,
                            onChanged: (value) {
                              setState(() {
                                _unLevel = "High";
                              });
                            },
                            title: Padding(
                              padding: const EdgeInsets.only(left: 20),
                              child: Text(
                                "High",
                                style: Theme.of(context)
                                    .textTheme
                                    .headlineMedium!
                                    .copyWith(
                                      fontFamily: "PoetsenOne",
                                      color: Colors.black,
                                      fontWeight: FontWeight.bold,
                                      fontSize: 24,
                                    ),
                              ),
                            ),
                          ),
                        ],
                      ),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        children: [
                          Text(
                            "Did you ever learn the fardu ain knowledge deeply?",
                            textAlign: TextAlign.center,
                            style: Theme.of(context)
                                .textTheme
                                .headlineMedium!
                                .copyWith(
                                  fontFamily: "PoetsenOne",
                                  color: Colors.black,
                                  fontWeight: FontWeight.bold,
                                  fontSize: 30,
                                ),
                          ),
                          const SizedBox(height: 20),
                          RadioListTile(
                            value: "Yes",
                            groupValue: _fardu,
                            activeColor: Colors.black,
                            onChanged: (value) {
                              setState(() {
                                _fardu = "Yes";
                              });
                            },
                            title: Padding(
                              padding: const EdgeInsets.only(left: 20),
                              child: Text(
                                "Yes",
                                style: Theme.of(context)
                                    .textTheme
                                    .headlineMedium!
                                    .copyWith(
                                      fontFamily: "PoetsenOne",
                                      color: Colors.black,
                                      fontWeight: FontWeight.bold,
                                      fontSize: 24,
                                    ),
                              ),
                            ),
                          ),
                          const SizedBox(height: 20),
                          RadioListTile(
                            value: "No",
                            groupValue: _fardu,
                            activeColor: Colors.black,
                            onChanged: (value) {
                              setState(() {
                                _fardu = "No";
                              });
                            },
                            title: Padding(
                              padding: const EdgeInsets.only(left: 20),
                              child: Text(
                                "No",
                                style: Theme.of(context)
                                    .textTheme
                                    .headlineMedium!
                                    .copyWith(
                                      fontFamily: "PoetsenOne",
                                      color: Colors.black,
                                      fontWeight: FontWeight.bold,
                                      fontSize: 24,
                                    ),
                              ),
                            ),
                          ),
                          const SizedBox(height: 20),
                          RadioListTile(
                            value: "Mostly forgotten",
                            groupValue: _fardu,
                            activeColor: Colors.black,
                            onChanged: (value) {
                              setState(() {
                                _fardu = "Mostly forgotten";
                              });
                            },
                            title: Padding(
                              padding: const EdgeInsets.only(left: 20),
                              child: Text(
                                "Mostly forgotten",
                                style: Theme.of(context)
                                    .textTheme
                                    .headlineMedium!
                                    .copyWith(
                                      fontFamily: "PoetsenOne",
                                      color: Colors.black,
                                      fontWeight: FontWeight.bold,
                                      fontSize: 24,
                                    ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ],
                    onPageChanged: (value) {
                      setState(() {
                        _page = value;
                      });
                    },
                  ),
                ),
              ),
              const SizedBox(height: 20),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: List.generate(
                  6,
                  (page) => Padding(
                    padding: const EdgeInsets.all(3),
                    child: Container(
                      width: 40,
                      height: 8,
                      decoration: BoxDecoration(
                        border: Border.all(
                          color: Colors.grey,
                        ),
                        borderRadius: BorderRadius.circular(10),
                        color: _page == page ? Colors.grey : Colors.white,
                      ),
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 20),
              if (_page == 5)
                Padding(
                  padding: const EdgeInsets.all(20),
                  child: Container(
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(10),
                      gradient: const LinearGradient(
                        colors: [Colors.orange, Colors.red],
                        begin: Alignment.topCenter,
                        end: Alignment.bottomCenter,
                      ),
                    ),
                    child: TextButton(
                      onPressed: () {},
                      child: const Text(
                        "NEXT",
                        style: TextStyle(
                          fontSize: 24,
                          color: Colors.black,
                        ),
                      ),
                    ),
                  ),
                ),
            ],
          ),
        );
      },
    );
  }
}
