import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:ukhwahood/model/user.dart';
import 'package:ukhwahood/util/api.dart';
import 'package:ukhwahood/util/error.dart';

enum Action {
  dislike(FontAwesomeIcons.xmark, Colors.grey),
  undo(FontAwesomeIcons.rotateRight, Colors.orange),
  superlike(FontAwesomeIcons.solidStar, Colors.blue),
  boost(FontAwesomeIcons.boltLightning, Colors.purple),
  like(FontAwesomeIcons.solidHeart, Colors.red);

  final IconData icon;
  final Color color;
  const Action(this.icon, this.color);
}

class DiscoverScreen extends StatefulWidget {
  final String authToken;
  const DiscoverScreen(this.authToken, {super.key});

  @override
  State<StatefulWidget> createState() => _DiscoverScreenState();
}

class _DiscoverScreenState extends State<DiscoverScreen> {
  User? _user;
  bool _loading = true;
  bool _enabled = true;

  Future<User?> _getMatchingUser() async {
    final res = await Api.get('/match', {
      'Authorization': 'Bearer ${widget.authToken}',
    });
    if (!res['success']) throw Error(res['message']);
    final match = res['match'];
    if (match == null) return null;
    return User(
      id: match['ID'],
      name: match['name'],
      email: match['email'],
      birthDate: DateTime.tryParse(match['birth_date'] ?? ''),
      state: match['state'],
      pray: match['pray'],
      level: match['level'],
      fardu: match['fardu'],
      socialUrl: match['social_url'],
      bio: match['bio'],
      education: match['education'],
      image: match['image'],
    );
  }

  User? _parseMatch(Map<String, dynamic> data) {
    return User(
      id: data['ID'],
      name: data['name'],
      state: data['state'],
      birthDate: DateTime.tryParse(data['birth_date']),
      image: data['image'],
    );
  }

  Future<void> _applyMatch(Action action) async {
    setState(() {
      _enabled = false;
    });
    final String path;
    switch (action) {
      case Action.dislike:
        path = '/user/${_user!.id}/dislike';
        break;
      case Action.undo:
        path = '/match/undo';
        break;
      case Action.superlike:
        path = '/user/${_user!.id}/superlike';
        break;
      case Action.boost:
        path = '/user/${_user!.id}/boostlike';
        break;
      case Action.like:
        path = '/user/${_user!.id}/like';
        break;
      default:
        return;
    }
    final res = await Api.multipart.post(path, null, {
      'Authorization': 'Bearer ${widget.authToken}',
    });
    if (!res['success']) {
      Fluttertoast.showToast(msg: res['message']);
      return;
    }
    final User? match;
    if (action == Action.undo) {
      match = _parseMatch(res['match']);
    } else {
      match = await _getMatchingUser();
    }
    setState(() {
      _user = match;
      _enabled = true;
    });
  }

  @override
  void initState() {
    super.initState();
    _getMatchingUser().then((user) {
      setState(() {
        _user = user;
        _loading = false;
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) {
      return const Center(child: CircularProgressIndicator());
    }
    if (_user == null) {
      return const Center(child: Text('No match found!'));
    }
    final dynamic age;
    if (_user!.birthDate == null) {
      age = 'N/A';
    } else {
      age = DateTime.now().difference(_user!.birthDate!).inDays ~/ 365;
    }
    return Stack(
      children: [
        Container(
          width: MediaQuery.of(context).size.width,
          height: MediaQuery.of(context).size.height * 0.4,
          decoration: BoxDecoration(
            borderRadius: const BorderRadius.only(
              bottomLeft: Radius.circular(50),
              bottomRight: Radius.circular(50),
            ),
            gradient: LinearGradient(
              colors: [
                Theme.of(context).colorScheme.primary,
                Theme.of(context).colorScheme.secondary,
              ],
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
            ),
          ),
        ),
        Padding(
          padding: const EdgeInsets.all(20),
          child: Column(
            mainAxisSize: MainAxisSize.max,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Text(
                'Discover',
                style: Theme.of(context).textTheme.headlineLarge?.copyWith(
                      color: Colors.white,
                    ),
              ),
              Expanded(
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(20),
                  child: Image.network(
                    'https://i.imgur.com/QPACK1y.jpg',
                    fit: BoxFit.fill,
                  ),
                ),
              ),
              Text(
                _user!.name ?? 'N/A',
                style: Theme.of(context).textTheme.headlineMedium?.copyWith(
                      color: Colors.black,
                    ),
              ),
              const SizedBox(height: 10),
              Row(
                children: [
                  Center(
                    child: Text(
                      _user!.state ?? 'N/A',
                      style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                            color: Colors.grey,
                            fontWeight: FontWeight.bold,
                          ),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Container(
                    padding: const EdgeInsets.all(5),
                    width: 30,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(10),
                      gradient: const LinearGradient(
                        colors: [Colors.pink, Colors.orange],
                        begin: Alignment.centerLeft,
                        end: Alignment.centerRight,
                      ),
                    ),
                    child: Text(
                      age.toString(),
                      textAlign: TextAlign.center,
                      style: Theme.of(context).textTheme.bodySmall?.copyWith(
                            color: Colors.white,
                          ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 10),
              Row(
                mainAxisSize: MainAxisSize.max,
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: Action.values
                    .map(
                      (action) => Container(
                        padding: const EdgeInsets.all(12),
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(40),
                          color: Colors.white,
                          boxShadow: const [
                            BoxShadow(
                              blurRadius: 5,
                              offset: Offset(0, 3),
                            ),
                          ],
                        ),
                        child: Center(
                          child: InkWell(
                            onTap: !_enabled ? null : () => _applyMatch(action),
                            child: Icon(
                              action.icon,
                              color: action.color,
                            ),
                          ),
                        ),
                      ),
                    )
                    .toList(),
              ),
            ],
          ),
        ),
      ],
    );
  }
}
