import 'package:flutter/material.dart';

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key});

  @override
  State<StatefulWidget> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      child: Column(
        mainAxisSize: MainAxisSize.max,
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Column(
            children: [
              Padding(
                padding: const EdgeInsets.all(10),
                child: Text(
                  'Profile',
                  textAlign: TextAlign.center,
                  style: Theme.of(context).textTheme.headlineMedium?.copyWith(
                        fontFamily: 'Nunito',
                        fontWeight: FontWeight.bold,
                        color: Colors.black,
                      ),
                ),
              ),
              Container(
                alignment: Alignment.center,
                child: Stack(
                  alignment: Alignment.center,
                  children: [
                    ClipOval(
                      child: Image.network(
                        'https://i.imgur.com/bLSePDl.png',
                        width: 140,
                        height: 140,
                        fit: BoxFit.fill,
                      ),
                    ),
                    Positioned(
                      right: 0,
                      bottom: 0,
                      child: InkWell(
                        onTap: () {},
                        child: Container(
                          padding: const EdgeInsets.all(10),
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(40),
                            color: const Color(0xFF587CF4).withOpacity(0.5),
                          ),
                          child: const Icon(
                            Icons.camera_alt,
                            color: Colors.white,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 10),
              Text(
                'Balqis',
                textAlign: TextAlign.center,
                style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                      fontFamily: 'Nunito',
                      fontSize: 20,
                      color: Colors.black,
                    ),
              ),
              Text(
                'Perlis',
                textAlign: TextAlign.center,
                style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                      fontFamily: 'Nunito',
                      fontSize: 16,
                      color: Colors.grey,
                    ),
              ),
              const SizedBox(height: 10),
            ],
          ),
          const SizedBox(
            height: 12,
            child: DecoratedBox(
              decoration: BoxDecoration(color: Color(0xFFFFF0F0)),
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Text(
                  'About',
                  style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                        fontFamily: 'Nunito',
                        fontSize: 22,
                        color: Colors.red,
                      ),
                ),
                const SizedBox(height: 10),
                Text(
                  'Full Name',
                  style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                        fontFamily: 'Nunito',
                        color: Colors.grey,
                      ),
                ),
                Text(
                  'Nur Balqis Azra Bt Saiful',
                  style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                        fontFamily: 'Nunito',
                        color: Colors.black,
                      ),
                ),
                const SizedBox(height: 10),
                Text(
                  'Email',
                  style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                        fontFamily: 'Nunito',
                        color: Colors.grey,
                      ),
                ),
                Text(
                  'balqis1999@gmail.com',
                  style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                        fontFamily: 'Nunito',
                        color: Colors.black,
                      ),
                ),
                const SizedBox(height: 10),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        children: [
                          Text(
                            'Birth Date',
                            style: Theme.of(context)
                                .textTheme
                                .bodyMedium
                                ?.copyWith(
                                  fontFamily: 'Nunito',
                                  color: Colors.grey,
                                ),
                          ),
                          Text(
                            '2 July 2001',
                            style: Theme.of(context)
                                .textTheme
                                .bodyMedium
                                ?.copyWith(
                                  fontFamily: 'Nunito',
                                  color: Colors.black,
                                ),
                          ),
                        ],
                      ),
                    ),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        children: [
                          Text(
                            'Gender',
                            style: Theme.of(context)
                                .textTheme
                                .bodyMedium
                                ?.copyWith(
                                  fontFamily: 'Nunito',
                                  color: Colors.grey,
                                ),
                          ),
                          Text(
                            'Female',
                            style: Theme.of(context)
                                .textTheme
                                .bodyMedium
                                ?.copyWith(
                                  fontFamily: 'Nunito',
                                  color: Colors.black,
                                ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 10),
                Text(
                  'Social URL',
                  style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                        fontFamily: 'Nunito',
                        color: Colors.grey,
                      ),
                ),
                Text(
                  'https://facebook.com/balqis_azra',
                  style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                        fontFamily: 'Nunito',
                        color: Colors.black,
                      ),
                ),
                const SizedBox(height: 10),
                Text(
                  'Bio',
                  style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                        fontFamily: 'Nunito',
                        color: Colors.grey,
                      ),
                ),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    'I love to travel',
                    'I can cook',
                  ]
                      .map(
                        (line) => Row(
                          mainAxisSize: MainAxisSize.max,
                          children: [
                            const Text(
                              '\u2022',
                              style: TextStyle(color: Colors.black),
                            ),
                            const SizedBox(width: 5),
                            Text(line),
                          ],
                        ),
                      )
                      .toList(),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
