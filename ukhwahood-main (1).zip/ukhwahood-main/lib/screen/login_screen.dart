import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:ukhwahood/screen/home_screen.dart';
import 'package:ukhwahood/util/api.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<StatefulWidget> createState() => _LoginScreenState();
}

enum Page {
  signin,
  signup,
}

class _LoginScreenState extends State<LoginScreen> {
  Page _page = Page.signin;
  bool _hidden = true;
  final _user = TextEditingController();
  final _pass = TextEditingController();
  bool _loading = false;

  void _login() async {
    setState(() => _loading = true);
    final res = await Api.multipart.post('/login', {
      'user': _user.text,
      'password': _pass.text,
    });
    if (!res['success']) {
      Fluttertoast.showToast(msg: res['message']);
    } else {
      final prefs = await SharedPreferences.getInstance();
      prefs.setString('AUTH_TOKEN', res['token']);
      if (mounted) {
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (context) => const HomeScreen()),
        );
      }
    }
    setState(() {
      _loading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.max,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Container(
              width: 100,
              height: 100,
              alignment: Alignment.centerRight,
              child: Padding(
                padding: const EdgeInsets.all(20),
                child: Image.asset("asset/img/logo-fyp.png"),
              ),
            ),
            const Text(
              'UKHWAHOOD',
              textAlign: TextAlign.center,
              style: TextStyle(
                fontFamily: 'RacingSansOne',
                // fontStyle: FontStyle.regular,
                color: Colors.orange,
                fontSize: 32,
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(20),
              child: Container(
                padding: const EdgeInsets.all(5),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(
                    color: Colors.black,
                    width: 2,
                  ),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.max,
                  // mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    Expanded(
                      child: Container(
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(10),
                          gradient: _page == Page.signin
                              ? const LinearGradient(
                                  colors: [Colors.orange, Colors.red],
                                  begin: Alignment.topCenter,
                                  end: Alignment.bottomCenter,
                                )
                              : null,
                        ),
                        child: TextButton(
                          onPressed: _loading
                              ? null
                              : () {
                                  setState(() {
                                    _page = Page.signin;
                                  });
                                },
                          child: const Text(
                            "Sign In",
                            style: TextStyle(
                              color: Colors.black,
                            ),
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(width: 5),
                    Expanded(
                      child: Container(
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(10),
                          gradient: _page == Page.signup
                              ? const LinearGradient(
                                  colors: [Colors.orange, Colors.red],
                                  begin: Alignment.topCenter,
                                  end: Alignment.bottomCenter,
                                )
                              : null,
                        ),
                        child: TextButton(
                          onPressed: _loading
                              ? null
                              : () {
                                  setState(() {
                                    _page = Page.signup;
                                  });
                                },
                          child: const Text(
                            "Sign Up",
                            style: TextStyle(
                              color: Colors.black,
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            _page == Page.signin
                ? Padding(
                    padding: const EdgeInsets.all(20),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        const Text(
                          "Email Address",
                          textAlign: TextAlign.start,
                        ),
                        const SizedBox(height: 5),
                        TextField(
                          decoration: InputDecoration(
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(10),
                              borderSide: const BorderSide(
                                color: Colors.grey,
                              ),
                            ),
                            hintText: "Your Email",
                          ),
                          controller: _user,
                        ),
                        const SizedBox(height: 20),
                        const Text(
                          "Password",
                          textAlign: TextAlign.start,
                        ),
                        const SizedBox(height: 5),
                        TextField(
                          decoration: InputDecoration(
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(10),
                              borderSide: const BorderSide(
                                color: Colors.grey,
                              ),
                            ),
                            suffixIcon: InkWell(
                              onTap: () {
                                setState(() {
                                  _hidden = !_hidden;
                                });
                              },
                              child: Icon(
                                _hidden
                                    ? FontAwesomeIcons.eyeSlash
                                    : FontAwesomeIcons.eye,
                              ),
                            ),
                            hintText: "Your Password",
                          ),
                          obscureText: _hidden,
                          controller: _pass,
                        ),
                        const SizedBox(height: 20),
                        const Text(
                          "Forgot Password?",
                          textAlign: TextAlign.end,
                        ),
                        const SizedBox(height: 60),
                        Container(
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(10),
                            gradient: const LinearGradient(
                              colors: [Colors.orange, Colors.red],
                              begin: Alignment.topCenter,
                              end: Alignment.bottomCenter,
                            ),
                          ),
                          child: TextButton(
                            onPressed: _loading ? null : _login,
                            child: const Text(
                              "Sign In",
                              style: TextStyle(
                                color: Colors.black,
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  )
                : Padding(
                    padding: const EdgeInsets.all(20),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        const Text(
                          "Email Address",
                          textAlign: TextAlign.start,
                        ),
                        const SizedBox(height: 5),
                        TextField(
                          decoration: InputDecoration(
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(10),
                              borderSide: const BorderSide(
                                color: Colors.grey,
                              ),
                            ),
                            hintText: "Your Email",
                          ),
                        ),
                        const SizedBox(height: 20),
                        const Text(
                          "Create a password",
                          textAlign: TextAlign.start,
                        ),
                        const SizedBox(height: 5),
                        TextField(
                          decoration: InputDecoration(
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(10),
                              borderSide: const BorderSide(
                                color: Colors.grey,
                              ),
                            ),
                            suffixIcon: InkWell(
                              onTap: () {
                                setState(() {
                                  _hidden = !_hidden;
                                });
                              },
                              child: Icon(
                                _hidden
                                    ? FontAwesomeIcons.eyeSlash
                                    : FontAwesomeIcons.eye,
                              ),
                            ),
                            hintText: "Your Password",
                          ),
                          obscureText: _hidden,
                        ),
                        const SizedBox(height: 20),
                        const Text(
                          "Confirm password",
                          textAlign: TextAlign.start,
                        ),
                        const SizedBox(height: 5),
                        TextField(
                          decoration: InputDecoration(
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(10),
                              borderSide: const BorderSide(
                                color: Colors.grey,
                              ),
                            ),
                            suffixIcon: InkWell(
                              onTap: () {
                                setState(() {
                                  _hidden = !_hidden;
                                });
                              },
                              child: Icon(
                                _hidden
                                    ? FontAwesomeIcons.eyeSlash
                                    : FontAwesomeIcons.eye,
                              ),
                            ),
                            hintText: "Your Password",
                          ),
                          obscureText: _hidden,
                        ),
                        const SizedBox(height: 60),
                        Container(
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(10),
                            gradient: const LinearGradient(
                              colors: [Colors.orange, Colors.red],
                              begin: Alignment.topCenter,
                              end: Alignment.bottomCenter,
                            ),
                          ),
                          child: TextButton(
                            onPressed: () {},
                            child: const Text(
                              "Sign Up",
                              style: TextStyle(
                                color: Colors.black,
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
          ],
        ),
      ),
    );
  }
}
