package com.tun.ukhwahood

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
